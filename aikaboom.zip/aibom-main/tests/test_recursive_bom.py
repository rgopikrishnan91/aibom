from aikaboom.utils.recursive_bom import discover_recursive_targets, generate_recursive_boms


def test_discover_recursive_targets_from_ai_relationship_fields():
    metadata = {
        "model_id": "parent-model",
        "rag_fields": {
            "trainedOnDatasets": {"value": "SQuAD, Common Crawl"},
            "testedOnDatasets": {"value": "MMLU"},
            "modelLineage": {"value": "meta-llama/Llama-3"},
        },
    }

    targets = discover_recursive_targets(metadata, bom_type="ai")

    assert [target["relationship_type"] for target in targets] == [
        "trainedOn",
        "trainedOn",
        "testedOn",
        "dependsOn",
    ]
    assert targets[-1]["bom_type"] == "ai"
    assert targets[-1]["resolvable_hint"] is True


def test_generate_recursive_boms_emits_child_exports():
    metadata = {
        "model_id": "parent-model",
        "rag_fields": {
            "trainedOnDatasets": {"value": "squad"},
        },
    }

    result = generate_recursive_boms(metadata, bom_type="ai", max_depth=1)

    assert result["beta"] is True
    assert result["generated_count"] == 1
    child = result["generated"][0]
    assert child["bom_type"] == "data"
    assert child["relationship_type"] == "trainedOn"
    assert child["spdx_validation"]["valid"] is True
    assert child["cyclonedx_data"]["bomFormat"] == "CycloneDX"
