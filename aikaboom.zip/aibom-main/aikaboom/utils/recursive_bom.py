"""Beta recursive BOM generation for relationship targets.

This module intentionally avoids recursive network/LLM calls. It turns
relationship targets discovered in a parent BOM into child BOM seed records and
standard exports that callers can inspect, save, or feed into a fuller pipeline.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List


AI_RELATIONSHIP_FIELDS = {
    "trainedOnDatasets": ("data", "trainedOn"),
    "testedOnDatasets": ("data", "testedOn"),
    "modelLineage": ("ai", "dependsOn"),
}


def _extract_value(value: Any) -> Any:
    if isinstance(value, dict) and "value" in value:
        return value.get("value")
    return value


def _split_targets(value: Any) -> List[str]:
    value = _extract_value(value)
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        pieces: Iterable[Any] = value
    elif isinstance(value, dict):
        pieces = value.values()
    else:
        pieces = re.split(r"[,;\n]+", str(value))

    targets: List[str] = []
    seen = set()
    for piece in pieces:
        text = str(_extract_value(piece) or "").strip()
        text = re.sub(r"^\s*[-*]\s*", "", text)
        if not text or text.lower() in {"unknown", "none", "n/a", "noassertion"}:
            continue
        key = text.lower()
        if key not in seen:
            seen.add(key)
            targets.append(text)
    return targets


def _safe_id(text: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9_.-]+", "-", text.strip()).strip("-")
    return slug or "related-artifact"


def discover_recursive_targets(metadata: Dict[str, Any], bom_type: str = "ai") -> List[Dict[str, Any]]:
    """Find relationship targets that can seed recursive beta BOMs."""
    if bom_type != "ai":
        return []

    rag_fields = metadata.get("rag_fields") or {}
    parent_id = metadata.get("model_id") or metadata.get("repo_id") or "parent-bom"
    targets: List[Dict[str, Any]] = []

    for field, (child_bom_type, relationship_type) in AI_RELATIONSHIP_FIELDS.items():
        for target in _split_targets(rag_fields.get(field)):
            targets.append(
                {
                    "source_field": field,
                    "relationship_type": relationship_type,
                    "target": target,
                    "bom_type": child_bom_type,
                    "parent": parent_id,
                    "resolvable_hint": "/" in target and " " not in target,
                }
            )
    return targets


def _build_child_metadata(target: Dict[str, Any]) -> Dict[str, Any]:
    name = target["target"]
    safe_id = _safe_id(name)
    if target["bom_type"] == "data":
        urls = {}
        if target["resolvable_hint"]:
            urls["huggingface"] = f"https://huggingface.co/datasets/{name}"
        return {
            "dataset_id": safe_id,
            "direct_metadata": {
                "name": name,
                "license": "NOASSERTION",
            },
            "rag_metadata": {
                "intendedUse": f"Referenced by {target['parent']} via {target['relationship_type']}",
            },
            "urls": urls,
            "recursive_source": target,
        }

    return {
        "model_id": safe_id,
        "repo_id": name if target["resolvable_hint"] else safe_id,
        "direct_fields": {
            "license": "NOASSERTION",
        },
        "rag_fields": {
            "model_name": name,
        },
        "recursive_source": target,
    }


def generate_recursive_boms(
    metadata: Dict[str, Any],
    bom_type: str = "ai",
    max_depth: int = 1,
    validate_spdx: bool = True,
    strict_spdx: bool = False,
) -> Dict[str, Any]:
    """Generate beta recursive child BOM exports from discovered relationships."""
    max_depth = max(0, int(max_depth or 0))
    targets = discover_recursive_targets(metadata, bom_type=bom_type) if max_depth > 0 else []
    generated: List[Dict[str, Any]] = []

    for target in targets:
        child_metadata = _build_child_metadata(target)
        child_type = target["bom_type"]
        item: Dict[str, Any] = {
            "beta": True,
            "depth": 1,
            "relationship_type": target["relationship_type"],
            "source_field": target["source_field"],
            "target": target["target"],
            "bom_type": child_type,
            "metadata": child_metadata,
        }

        try:
            from aikaboom.utils.spdx_validator import SPDXValidator, validate_spdx_export

            spdx = SPDXValidator(bom_type=child_type).validate_and_convert(child_metadata)
            item["spdx_data"] = spdx
            if validate_spdx:
                item["spdx_validation"] = validate_spdx_export(
                    spdx,
                    strict=strict_spdx,
                    bom_type=child_type,
                )
        except Exception as exc:
            item["spdx_error"] = str(exc)

        try:
            from aikaboom.utils.cyclonedx_exporter import bom_to_cyclonedx

            item["cyclonedx_data"] = bom_to_cyclonedx(child_metadata, bom_type=child_type)
        except Exception as exc:
            item["cyclonedx_error"] = str(exc)

        generated.append(item)

    return {
        "beta": True,
        "enabled": True,
        "max_depth": max_depth,
        "strategy": "relationship-seed-exports",
        "generated_count": len(generated),
        "generated": generated,
        "warnings": [
            "Recursive BOM generation is beta and emits child BOM seed exports from discovered relationship targets.",
            "It does not perform recursive network or LLM enrichment automatically.",
        ],
    }
