"""AIkaBoOM - AI Bills of Materials"""
__version__ = "1.0.0"

from aikaboom.utils.spdx_validator import validate_bom_to_spdx, validate_spdx_export
from aikaboom.utils.recursive_bom import discover_recursive_targets, generate_recursive_boms

try:
    from aikaboom.core.processors import AIBOMProcessor, DATABOMProcessor
except ImportError:
    AIBOMProcessor = None
    DATABOMProcessor = None

try:
    from aikaboom.core.agentic_rag import AgenticRAG, DirectLLM
except ImportError:
    AgenticRAG = None
    DirectLLM = None

try:
    from aikaboom.utils.openrouter_models import (
        list_openrouter_models,
        list_free_openrouter_models,
        pick_free_openrouter_model,
    )
except ImportError:
    list_openrouter_models = None
    list_free_openrouter_models = None
    pick_free_openrouter_model = None

try:
    from aikaboom.utils.cyclonedx_exporter import CycloneDXExporter, bom_to_cyclonedx
except ImportError:
    CycloneDXExporter = None
    bom_to_cyclonedx = None

__all__ = [
    "AIBOMProcessor",
    "DATABOMProcessor",
    "AgenticRAG",
    "DirectLLM",
    "list_openrouter_models",
    "list_free_openrouter_models",
    "pick_free_openrouter_model",
    "CycloneDXExporter",
    "bom_to_cyclonedx",
    "validate_bom_to_spdx",
    "validate_spdx_export",
    "discover_recursive_targets",
    "generate_recursive_boms",
]
